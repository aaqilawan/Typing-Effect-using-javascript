let texts = ['website','illustrator','designing'];
let count = 0; //for full character count 
let index = 0; //for letters counting 
let currentText = ''; 
let letter = '';

// immediately call the function syntax
(function type(){
    if(count === texts.length){
        count = 0;
    }
    currentText = texts[count]; //e.g: website
    //slice method use for value get or show
    letter =  currentText.slice(0, ++index); 

    document.querySelector('.typing').textContent = letter;

    if(letter.length === currentText.length){
        count++;
        index = 0;
    }
    setTimeout(type,400);
}());